# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy


class FsDataItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    rcept_no = scrapy.Field()
    corp_code = scrapy.Field()
    stock_code = scrapy.Field()
    account_nm = scrapy.Field()
    fs_div = scrapy.Field()
    fs_nm = scrapy.Field()
    sj_div = scrapy.Field()
    sj_nm = scrapy.Field()
    thstrm_nm = scrapy.Field()
    thstrm_dt = scrapy.Field()
    thstrm_amount= scrapy.Field()
    frmtrm_nm  = scrapy.Field()
    frmtrm_dt  = scrapy.Field()
    frmtrm_amount  = scrapy.Field()
    bfefrmtrm_nm = scrapy.Field()
    bfefrmtrm_dt = scrapy.Field()
    bfefrmtrm_amount = scrapy.Field()
    ord = scrapy.Field()
