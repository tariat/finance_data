# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html

import pymysql

def remove_for_price(val):
    val = val.replace(" ","")
    val = val.replace(",", "")

    return val

class FsDataPipeline(object):

    db_conf = {
        "host": "127.0.0.1",
        "user": "test",
        "password": "test11",
        "database": "finance",
    }

    def process_item(self, item, spider):

        table_nm = "FS_DATA"

        con = pymysql.connect(**self.db_conf)
        cur = con.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS {} (
                rcept_no VARCHAR(20),
                corp_code VARCHAR(8),
                stock_code VARCHAR(6),
                account_nm VARCHAR(20),
                fs_div VARCHAR(10),
                fs_nm VARCHAR(30),
                sj_div VARCHAR(10),
                sj_nm VARCHAR(30),
                thstrm_nm VARCHAR(10),
                thstrm_dt VARCHAR(30),
                thstrm_amount BIGINT,
                frmtrm_nm VARCHAR(10),
                frmtrm_dt VARCHAR(30),
                frmtrm_amount BIGINT,
                bfefrmtrm_nm VARCHAR(10),
                bfefrmtrm_dt VARCHAR(30),
                bfefrmtrm_amount BIGINT,
                ord INT,
                collected_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                primary key (rcept_no, corp_code, thstrm_dt, ord))
            """.format(table_nm)
        )

        for rcept_no, corp_code, stock_code, account_nm, fs_div, fs_nm,sj_div, sj_nm,thstrm_nm,thstrm_dt,thstrm_amount, frmtrm_nm, frmtrm_dt, frmtrm_amount,bfefrmtrm_nm, bfefrmtrm_dt, bfefrmtrm_amount, ord  in zip(
                item["rcept_no"], item["corp_code"], item["stock_code"], item["account_nm"], item["fs_div"],
                item["fs_nm"], item["sj_div"],item["sj_nm"], item["thstrm_nm"], item["thstrm_dt"],
                item["thstrm_amount"], item["frmtrm_nm"],item["frmtrm_dt"], item["frmtrm_amount"],
                item["bfefrmtrm_nm"], item["bfefrmtrm_dt"], item["bfefrmtrm_amount"], item["ord"]):

            cur.execute(
                """
                REPLACE INTO {} ( rcept_no, corp_code, stock_code, account_nm, fs_div, fs_nm, sj_div, sj_nm, thstrm_nm,
                                  thstrm_dt,thstrm_amount, frmtrm_nm, frmtrm_dt, frmtrm_amount,bfefrmtrm_nm,bfefrmtrm_dt,
                                  bfefrmtrm_amount, ord) 
                                  VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""".format(table_nm),
                (
                    rcept_no, corp_code, stock_code, account_nm, fs_div, fs_nm, sj_div, sj_nm, thstrm_nm, thstrm_dt, remove_for_price(thstrm_amount), frmtrm_nm, frmtrm_dt, remove_for_price(frmtrm_amount), bfefrmtrm_nm, bfefrmtrm_dt, remove_for_price(bfefrmtrm_amount), ord
                )
            )

        con.commit()
        con.close()

        return 0
