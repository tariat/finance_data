# -*- coding: utf-8 -*-
import scrapy
from fs_data.items import FsDataItem

class CollectFsDataSpider(scrapy.Spider):
    name = 'collect_fs_data'
    col_list = ['rcept_no', 'corp_code', 'stock_code', 'account_nm', 'fs_div', 'fs_nm', 'sj_div',
                'sj_nm','thstrm_nm','thstrm_dt','thstrm_amount', 'frmtrm_nm', 'frmtrm_dt',
                'frmtrm_amount','bfefrmtrm_nm','bfefrmtrm_dt','bfefrmtrm_amount', 'ord']
    allowed_domains = ['opendart.fss.or.kr']

    def __init__(self, year = "2018", corp_code = "00126380", reprt_code = "11011", *args, **kwargs):
        super(CollectFsDataSpider, self).__init__(*args, **kwargs)

        CRTFC_KEY = "발급받은 API키를 입력합니다"

        url = "https://opendart.fss.or.kr/api/fnlttSinglAcnt.xml?crtfc_key={}&corp_code={}&bsns_year={}&reprt_code={}".format(
            CRTFC_KEY, str(corp_code), str(year), str(reprt_code))

        self.start_urls = [url]

    def parse(self, response):
        # API수신결과 확인
        if response.xpath("//status/text()").get() !="000":
            raise Exception(response.xpath("//message/text()").get())

        item = FsDataItem()

        # item_list = response.xpath("//list").getall()
        # type(item)

        # for i in item_list:
        #     print(i)
        for col in self.col_list:
            item[col] = response.xpath("//list/{}/text()".format(col)).getall()

        return item

