from urllib.request import urlopen
from urllib.request import urlretrieve
from bs4 import BeautifulSoup
from tqdm import tqdm
import os

def collect_corp_code():
    """
    주식종목코드가 있는 기업의 고유번호를 반환
    :return: 기업의 고유번호 리스트
    """
    CRTFC_KEY = "발급받은 API KEY를 입력합니다"
    url = "https://opendart.fss.or.kr/api/corpCode.xml?crtfc_key={}".format(CRTFC_KEY)
    urlretrieve(url, "corp_code.zip")
    os.system("unzip corp_code.zip")

    result =""
    with open("CORPCODE.xml", "r") as file:
        for f in file:
            result = result + f

    result_xml = BeautifulSoup(result, 'html.parser')
    all_list = result_xml.find_all("list")
    corp_code = []

    for l in tqdm(all_list):
        if l.find("stock_code").text != ' ':
            corp_code.append(l.find("corp_code").text)

    return corp_code

if __name__ == '__main__':
    corp_list = collect_corp_code()
    os.chdir("/Users/open/PycharmProjects/env_scrapy/fs_data")

    for c in tqdm(corp_list):
        os.system("source /Users/open/PycharmProjects/env_scrapy/venv/bin/activate;scrapy crawl -a year=2019 -a corp_code={} -a rept_code=11011 --logfile=./log/collect_fs_data.log collect_fs_data".format(c))
