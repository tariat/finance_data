import os
from datetime import datetime
from dateutil.relativedelta import relativedelta

code_list = ['013Y202' # 생산자물가지수
             ,'021Y125' # 소비자물가지수
             ,'098Y001' # 금리 정보
             ]

from_ym = datetime.strftime(datetime.today() + relativedelta(months=-1), "%Y%m")
to_ym = from_ym

log_file = "log_" + datetime.strftime(datetime.today(), "%Y%m%d") + ".log"
command_list = ["scrapy crawl -a code={} -a from_ym={} -a to_ym={} --logfile=./log/{} collect_base_rate"
                .format(x,from_ym,to_ym, log_file) for x in code_list]

command = ';'.join(command_list)

os.chdir("/Users/open/PycharmProjects/env_scrapy/kor_bank_data")
os.system("source /Users/open/PycharmProjects/env_scrapy/venv/bin/activate;"+command)

