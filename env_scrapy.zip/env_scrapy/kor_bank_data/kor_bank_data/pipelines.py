# -*- coding: utf-8 -*-
import pymysql
import logging

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


class KorBankDataPipeline(object):
    db_conf = {
        "host": "127.0.0.1",
        "user": "test",
        "password": "test11",
        "database": "finance",
    }

    def process_item(self, item, spider):

        logging.info("connect mysql")
        self.con = pymysql.connect(**self.db_conf)
        self.cur = self.con.cursor()
        self.cur.execute(
            """
            CREATE TABLE IF NOT EXISTS kor_bank (
            stat_name VARCHAR(100),
            item_code1 VARCHAR(10),
            item_name1 VARCHAR(50),
            item_code2 VARCHAR(10),
            item_name2 VARCHAR(50),
            item_code3 VARCHAR(10),
            item_name3 VARCHAR(50),
            unit_name VARCHAR(50),
            time VARCHAR(10),
            data_value VARCHAR(50),
            stat_code VARCHAR(10),
            primary key (time, stat_code, item_code1, item_code2, item_code3) )
            """
        )
        for sn, ic1, in1, ic2, in2, ic3, in3, un, time, dv, sc in zip(
            item["stat_name"], item["item_code1"], item["item_name1"],
            item["item_code2"], item["item_name2"], item["item_code3"],
            item["item_name3"], item["unit_name"], item["time"], item["data_value"], item["stat_code"]
        ):
            self.cur.execute(
                """
                REPLACE INTO kor_bank (stat_name, item_code1, item_name1, item_code2, item_name2,
                                      item_code3, item_name3, unit_name, time, data_value, stat_code)  
                VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)                
                """, (sn, ic1, in1, ic2, in2, ic3, in3, un, time, dv, sc)
            )

        self.con.commit()
        self.con.close()

        logging.info("{} is completed".format(len(item)))

        return item



