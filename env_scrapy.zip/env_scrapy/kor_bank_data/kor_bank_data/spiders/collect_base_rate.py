# -*- coding: utf-8 -*-
import scrapy
from kor_bank_data.items import KorBankDataItem
import logging

class CollectBaseRateSpider(scrapy.Spider):

    SERVICE = "StatisticSearch"
    API_KEY="발급받은 API키를 입력합니다"
    # CODE = "098Y001"
    # CYCLE = "MM"
    # FROM_YM="201912"
    # FROM_YM = category
    # TO_YM = "201912"

    name = 'collect_base_rate'
    allowed_domains = ['ecos.bok.or.kr']

    # collect_url = "http://ecos.bok.or.kr/api/{}/{}/json/kr/1/1000/{}/{}/{}/{}".format(
    #     SERVICE, API_KEY, CODE, CYCLE, FROM_YM, TO_YM
    # )
    #
    # start_urls = [collect_url]

    def __init__(self, code="098Y001", cycle="MM", from_ym=None, to_ym=None,  *args, **kwargs):
        super(CollectBaseRateSpider, self).__init__(*args, **kwargs)
        self.start_urls = ["http://ecos.bok.or.kr/api/{}/{}/json/kr/1/1000/{}/{}/{}/{}".format(
        self.SERVICE, self.API_KEY, code, cycle, from_ym, to_ym)]

    def parse(self, response):
        item = KorBankDataItem()

        import json
        result = json.loads(response.body_as_unicode())

        try:
            if result["RESULT"]["MESSAGE"]=="해당하는 데이터가 없습니다.":
                logging.error("{} is empty".format(response.url))
                logging.error("해당하는 데이터가 없습니다.")
                return None
        except:
            pass

        print(result)
        result_row = result["StatisticSearch"]["row"]

        stat_code = list()
        stat_name = list()
        item_code1 = list()
        item_name1 = list()
        item_code2 = list()
        item_name2 = list()
        item_code3 = list()
        item_name3 = list()
        unit_name = list()
        time = list()
        data_value = list()

        for i in result_row:
            print(i)
            stat_code.append(i.get("STAT_CODE", ""))
            stat_name.append(i.get("STAT_NAME", ""))
            item_code1.append(i.get("ITEM_CODE1", ""))
            item_name1.append(i.get("ITEM_NAME1", ""))
            item_code2.append(i.get("ITEM_CODE2", ""))
            item_name2.append(i.get("ITEM_NAME2", ""))
            item_code3.append(i.get("ITEM_CODE3", ""))
            item_name3.append(i.get("ITEM_NAME3", ""))
            unit_name.append(i.get("UNIT_NAME", ""))
            time.append(i.get("TIME", ""))
            data_value.append(i.get("DATA_VALUE", ""))

        item["stat_code"] = stat_code
        item["stat_name"] = stat_name
        item["item_code1"] = item_code1
        item["item_name1"] = item_name1
        item["item_code2"] = item_code2
        item["item_name2"] = item_name2
        item["item_code3"] = item_code3
        item["item_name3"] = item_name3
        item["unit_name"] = unit_name
        item["time"] = time
        item["data_value"] = data_value

        return item
