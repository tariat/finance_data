# -*- coding: utf-8 -*-
import scrapy
import pandas as pd
import real_estate_data.items as re_item
import real_estate_data.utils as utils
import datetime

class CollectRealEstateSpider(scrapy.Spider):
    
    name = 'collect_real_estate'
    allowed_domains = ['openapi.molit.go.kr']

    apt_sale_col = ("거래금액", "건축년도", "년", "월", "일", "법정동", "아파트", "전용면적", "지번", "지역코드", "층")
    apt_lent_col = ("건축년도", "년", "법정동", "보증금액", "아파트", "월", "월세금액", "일", "전용면적", "지번", "지역코드", "층")
    col_kor_eng = {"거래금액":"price", "건축년도":"build_y", "년":"year", "월":"month", "일":"day", "법정동":"dong",
                   "아파트": "apt_nm", "전용면적":"size", "지번":"jibun", "지역코드":"ji_code", "층":"floor",
                   "보증금액": "bo_price", "월세금액": "lent_price"}

    # col_dt_type = {"거래금액":"INT", "건축년도":"INT", "년":"INT", "월":"TINYINT", "일":"TINYINT", "법정동":"VARCHAR(20)",
    #                "아파트": "VARCHAR(50)", "전용면적":"FLOAT", "지번":"VARCHAR(10)", "지역코드":"VARCHAR(10)", "층":"INT"}

    def __init__(self, ym=201812, lawd_cd=None, *args, **kwargs):
        super(CollectRealEstateSpider, self).__init__(*args, **kwargs)

        API_KEY = "발급받은 API키를 넣습니다"
        apt_lent_url = "http://openapi.molit.go.kr:8081/OpenAPI_ToolInstallPackage/service/rest/RTMSOBJSvc/getRTMSDataSvcAptRent"
        apt_sale_url = "http://openapi.molit.go.kr:8081/OpenAPI_ToolInstallPackage/service/rest/RTMSOBJSvc/getRTMSDataSvcAptTrade"

        self.ym = ym

        if lawd_cd==None:
            temp = utils.get_lawd_cd()
            self.lawd_list = temp["ji_code"]
        else:
            self.lawd_list = [str(lawd_cd)]

        url_list= list()

        for l in self.lawd_list:
            url_list.append("{}?LAWD_CD={}&DEAL_YMD={}&serviceKey={}".format(apt_sale_url,l,self.ym, API_KEY))
            url_list.append("{}?LAWD_CD={}&DEAL_YMD={}&serviceKey={}".format(apt_lent_url, l, self.ym, API_KEY))

        self.start_urls = url_list


    def parse(self, response):

        url_cla = utils.parse_url(response.url)

        if response.xpath("//resultCode/text()").get() != "00":
            print(response.xpath("//resultMsg/text()").get())
            raise Exception(response.xpath("//resultMsg/text()").get())

        if url_cla == "getRTMSDataSvcAptTrade":
            item = re_item.AptSaleItem()
            for col in self.apt_sale_col:
                item[self.col_kor_eng[col]] = response.xpath("//item/{}/text()".format(col)).getall()
            item["url"] = response.url
            item["ym"] = self.ym
            return item
        elif url_cla == "getRTMSDataSvcAptRent":
            item = re_item.AptLentItem()
            for col in self.apt_lent_col:
                item[self.col_kor_eng[col]] = response.xpath("//item/{}/text()".format(col)).getall()
            item["url"] = response.url
            item["ym"] = self.ym
            return item



