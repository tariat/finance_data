# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html

import pymysql
import logging
import real_estate_data.utils as utils

def remove_for_price(val):
    val = val.replace(" ","")
    val = val.replace(",", "")

    return val

def process_apt_sale(db_conf, item):
    """
    아파트 매매 내역을 DB에 저장합니다.
    :param db_conf: DB접속정보
    :param item: 수집한 ITEM정보
    :return: 수집결과를 DB에 저장
    """
    table_nm = "APT_SALE"

    con = pymysql.connect(**db_conf)
    cur = con.cursor()

    # 테이블이 이미 있으면 생략 가능
    # cur.execute(
    #     """
    #     CREATE TABLE IF NOT EXISTS {} (
    #     price int,
    #     build_y int,
    #     year int,
    #     month int,
    #     day int,
    #     dong VARCHAR(20),
    #     apt_nm VARCHAR(50),
    #     size float,
    #     jibun VARCHAR(10),
    #     ji_code VARCHAR(10),
    #     floor int,
    #     ym int,
    #     id int,
    #     collected_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    #     primary key (ji_code, ym, id))
    #     """.format(table_nm)
    # )

    idx=1
    item["floor"] = ["-9" if i.replace(" ","")=="" or i==' ' else i for i in item["floor"]]

    for price, build_y, year, month, day, dong, apt_nm, size, jibun, ji_code, floor in zip(
            item["price"], item["build_y"], item["year"],
            item["month"], item["day"], item["dong"],
            item["apt_nm"], item["size"], item["jibun"], item["ji_code"], item["floor"]):
        cur.execute(
            """
            REPLACE INTO {} (price, build_y, year, month, day,
                                  dong, apt_nm, size, jibun, ji_code, floor, ym, id)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """.format(table_nm), (remove_for_price(price), build_y, year, month, day,
                  dong, apt_nm, size, jibun, ji_code, floor, item["ym"], idx)
        )
        idx+=1

    con.commit()
    con.close()

    return 0

def process_apt_lent(db_conf, item):
    """
    아파트 전세거래 내역을 DB에 저장합니다.
    :param db_conf: DB접속정보
    :param item: 수집한 ITEM정보
    :return: 수집결과를 DB에 저장
    """
    table_nm = "APT_LENT"

    con = pymysql.connect(**db_conf)
    cur = con.cursor()

    # 테이블이 이미 있으면 생략가능
    # cur.execute(
    #     """
    #     CREATE TABLE IF NOT EXISTS {} (
    #     build_y int,
    #     year int,
    #     dong VARCHAR(20),
    #     bo_price int,
    #     apt_nm VARCHAR(50),
    #     month int,
    #     lent_price int,
    #     day int,
    #     size float,
    #     jibun VARCHAR(10),
    #     ji_code VARCHAR(10),
    #     floor int,
    #     ym int,
    #     id int,
    #     collected_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    #     primary key (ji_code, ym, id))
    #     """.format(table_nm)
    # )

    idx = 1

    item["floor"] = ["-9" if i.replace(" ","")=="" or i==' ' else i for i in item["floor"]]

    for build_y, year, dong, bo_price, apt_nm, month, lent_price, day, size, jibun, ji_code, floor in zip(
            item["build_y"], item["year"], item["dong"], item["bo_price"], item["apt_nm"],
            item["month"], item["lent_price"], item["day"], item["size"], item["jibun"],
            item["ji_code"], item["floor"]):
        cur.execute(
            """
            REPLACE INTO {} ( build_y, year, dong, bo_price, apt_nm,
                              month, lent_price, day, size, jibun,
                              ji_code, floor,
                              ym, id) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""".format(table_nm),
            (build_y, year, dong, remove_for_price(bo_price), apt_nm, month, remove_for_price(lent_price), day, size, jibun, ji_code, floor, item["ym"], idx)
        )
        idx+=1

    con.commit()
    con.close()

    return 0

class RealEstateDataPipeline(object):
    db_conf = {
        "host": "127.0.0.1",
        "user": "test",
        "password": "test11",
        "database": "finance",
    }
    # db_conf = {
    #     "host": "tariat.mysql.pythonanywhere-services.com",
    #     "user": "tariat",
    #     "password": "kjh13200",
    #     "database": "tariat$finance",
    # }

    def process_item(self, item, spider):

        url_cla = utils.parse_url(item["url"])
        logging.info(url_cla)

        if url_cla=="getRTMSDataSvcAptTrade":
            # logging.warn("아파트 매매내역 {} 수집 시작".format(item["ym"]))
            process_apt_sale(self.db_conf, item)
            # logging.warn("아파트 매매내역 {}, {} cnt 수집완료".format(item["ym"], len(item["year"])))
        elif url_cla=="getRTMSDataSvcAptRent":
            # logging.warn("아파트 전세내역 {} 수집 시작".format(item["ym"]))
            process_apt_lent(self.db_conf, item)
            # logging.warn("아파트 전세내역 {}, {} cnt 수집완료".format(item["ym"], len(item["year"])))

        return item
