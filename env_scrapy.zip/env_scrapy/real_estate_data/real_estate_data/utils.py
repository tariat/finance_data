import pandas as pd

def get_lawd_cd():
    """
    시구 기준의 지역코드를 불러옵니다.
    """
    code=pd.read_excel("./real_estate_data/data/KIKcd_B.20181210.xlsx")
    # code=pd.read_excel("./data/KIKcd_B_20180122.xlsx")
    code["ji_code"] = code["법정동코드"].astype(str).str[0:5]
    code_sigu = code[["ji_code", "시도명", "시군구명"]]
    code_sigu.columns = ["ji_code", "si", "gu"]
    code_sigu = code_sigu.drop_duplicates()
    code_sigu = code_sigu.reset_index(drop=True)
    code_sigu = code_sigu.fillna("-")

    return code_sigu

def parse_url(url):
    result_url = url.split("RTMSOBJSvc/")[1].split("?")[0]
    return result_url