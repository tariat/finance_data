# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/items.html

import scrapy

class AptSaleItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()

    price = scrapy.Field()
    build_y = scrapy.Field()
    year = scrapy.Field()
    month = scrapy.Field()
    day = scrapy.Field()
    dong = scrapy.Field()
    apt_nm = scrapy.Field()
    size = scrapy.Field()
    jibun = scrapy.Field()
    ji_code = scrapy.Field()
    floor = scrapy.Field()
    ym = scrapy.Field()
    url = scrapy.Field()

class AptLentItem(scrapy.Item):

    build_y = scrapy.Field()
    year = scrapy.Field()
    dong = scrapy.Field()
    bo_price = scrapy.Field()
    apt_nm = scrapy.Field()
    month = scrapy.Field()
    lent_price = scrapy.Field()
    day = scrapy.Field()
    size = scrapy.Field()
    jibun = scrapy.Field()
    ji_code = scrapy.Field()
    floor = scrapy.Field()
    ym = scrapy.Field()
    url = scrapy.Field()
